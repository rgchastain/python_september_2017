# -*- coding: utf-8 -*-
from __future__ import unicode_literals
from django.contrib import messages
from django.db import models

class UserManager(models.Manager):
	def validate(self, form_data):
		errors = []
		if len(form_data['name']) < 6:
			errors.append("course name must be more than 5 characters.")
		if len(form_data['desc']) < 16:
			errors.append("description must be more than 15 characters")
		return errors

	def create_course(self, form_data):
		course = self.create(
			name = form_data['name'],
			desc = form_data['desc'],
			)
		return course
		

class Course(models.Model):
	name = models.CharField(max_length = 40)
	desc = models.CharField(max_length = 500)
	created_at = models.DateTimeField(auto_now_add = True)
	updated_at = models.DateTimeField(auto_now = True)

	objects = UserManager()