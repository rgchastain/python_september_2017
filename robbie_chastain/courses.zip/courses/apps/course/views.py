# -*- coding: utf-8 -*-
from __future__ import unicode_literals
from django.contrib import messages
from django.shortcuts import render, redirect, reverse
from .models import Course

def index(request):

	context = {
		'courses': Course.objects.all()
	}
	return render(request, 'course/index.html', context)

def create(request):
	if request.method == "POST":
		errors = Course.objects.validate(request.POST)
		if errors:
			for error in errors:
				messages.error(request, error)
			return redirect(reverse('all_courses'))
	course = Course.objects.create_course(request.POST)
	return redirect(reverse('all_courses'))

def destroy(request, id):
	course = Course.objects.get(id = id)

	context = {
		'course': course
	}
	return render(request, 'course/destroy.html', context)

def delete(request, id):
	Course.objects.get(id = id).delete()
	return redirect(reverse('all_courses'))