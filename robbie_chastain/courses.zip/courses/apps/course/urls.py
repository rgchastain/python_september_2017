from django.conf.urls import url
from . import views
urlpatterns = [
	url(r'^$', views.index, name = 'all_courses'),
	url(r'^create$', views.create, name = 'create_course'),
	url(r'^destroy/(?P<id>\d+)$', views.destroy, name = 'destroy_course'),
	url(r'^delete/(?P<id>\d+)$', views.delete, name = 'delete_course'),
]